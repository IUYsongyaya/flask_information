## RDBMS和数据库的关系

![](/Images/16day/QQ20170814-163342@2x.png)