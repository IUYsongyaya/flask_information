# MySQL与python交互 {#mysql与python交互}

* 关于MySQL的主要知识点学习完了，接下来需要能够使用python与MySQL进行交互，通过python完成数据的增加、修改、删除、查询



